import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:school_project/models/user.dart';

class DatabaseService {

  final String uid;

  DatabaseService({ this.uid });
  // collection reference
  final CollectionReference userCollection = Firestore.instance.collection('users');

  Future updateUserData(int grade, String name, String school) async {
    return await userCollection.document(uid).setData({
      'grade': grade,
      'name': name,
      'school': school,
    });
  }

  // userData from snapshot
  UserData _userDataFromSnapshot(DocumentSnapshot snapshot) {
    return UserData(
      uid: uid,
      name: snapshot.data['name'],
      grade: snapshot.data['grade'],
      school: snapshot.data['school']
    );
  }


  // get user doc stream
  Stream<UserData> get userData {
    return userCollection.document(uid).snapshots()
      .map(_userDataFromSnapshot);
  }

}